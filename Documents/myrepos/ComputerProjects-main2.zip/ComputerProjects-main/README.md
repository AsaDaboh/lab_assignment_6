# ComputerProjects
My new Repo made for CS1: how to build your repository
